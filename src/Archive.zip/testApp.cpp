#include "testApp.h"
#include <stdio.h>

//--------------------------------------------------------------
void testApp::setup(){
    
    mScreenHeight = 510;
    Shapes shape;
    
    for (int i = 0; i < 4; i ++ ) {
        cout<<shapes.test[i]<<" ";
    }
    for (int i = 0 ; i < SHAPE_BLOCKS; i++) {
        for (int j = 0; j < SHAPE_BLOCKS; j++ ) {
            cout<<shapes.mShapes[1][1][i][j]<<" ";
        }
        cout<<endl;
    }
    
    field = new Field(&shapes, mScreenHeight);
    game = new Game(field, &shapes, mScreenHeight);
    
    interval = 1000;
    timerReset = ofGetElapsedTimeMillis();
    
    

}

//--------------------------------------------------------------
void testApp::update(){
    
    //update screen
    //move a shape down if game is not over yet
    if (!field->isGameOver()) {
        if (ofGetElapsedTimeMillis() - timerReset > interval) {  
            if (field->isPossibleMovement(game->mPosX, game->mPosY + 1, game->mShape, game->mRotation)) {
                game->mPosY++;
                cout<<game->mPosY<<endl;
            } else {
                field->storeShape(game->mPosX, game->mPosY, game->mShape, game->mRotation);
                field->deletePossibleLines ();
                game->createNewShape();
            }
            timerReset = ofGetElapsedTimeMillis();
        }
    }

}

//--------------------------------------------------------------
void testApp::draw(){
    
    clearScreen();
    game->drawScene();

}

//--------------------------------------------------------------
void testApp::keyPressed(int key){
    cout<<key<<endl;
    
    if (key == 122) {
        game->createNewShape('z');
    }
    if (key == 116) {
        game->createNewShape('t');
    }
    
    
    
    
    if (key == 32) {
        //clearscreen
        //game.drawScene();  //draw scene
        //put the graphic content in the screen
    }
    if (key == 358) {
        //move right
        if (field->isPossibleMovement (game->mPosX + 1, game->mPosY, game->mShape, game->mRotation)) {
            game->mPosX++;
        }
    }
    if (key == 356) {
        //move left
        if (field->isPossibleMovement (game->mPosX - 1, game->mPosY, game->mShape, game->mRotation)) {
            game->mPosX--;
        }
    }
    if (key == 359) {
        //move down
        if (field->isPossibleMovement (game->mPosX, game->mPosY + 1, game->mShape, game->mRotation)) {
            game->mPosY++;	
        }
    }
    if (key == 357) {
        //move up
        if (field->isPossibleMovement (game->mPosX, game->mPosY, game->mShape, (game->mRotation + 1) % 4)) {
            game->mRotation = (game->mRotation + 1) % 4;
        }
    }
    if (key == 32) {
        //spacebar, drop
        while (field->isPossibleMovement(game->mPosX, game->mPosY, game->mShape, game->mRotation)) { 
            game->mPosY++; 
        }
        field->storeShape(game->mPosX, game->mPosY - 1, game->mShape, game->mRotation);
        field->deletePossibleLines ();
        /*
        if (field->isGameOver()) {
            exit(0);
        }*/
        game->createNewShape();
    }
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}



void testApp::wait(float seconds) {
    clock_t endwait;
    endwait = clock () + seconds * CLOCKS_PER_SEC ;
    while (clock() < endwait) {}
}

void testApp::clearScreen() {
    ofSetColor(0);
    ofRect(0, 0, ofGetWidth(), ofGetHeight());
}
    
    
    
    
    


